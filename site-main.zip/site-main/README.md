# Site

<a href="https://www.php.net/" target="_blank">
    <image src="https://img.shields.io/badge/PhP-vX-777BB4.svg?logo=php&longCache=true&style=flat">
</a>
<a href="#">
    <image src="https://img.shields.io/badge/HTML-v5-E34F26.svg?logo=html5&longCache=true&style=flat">
</a>
<a href="#">
    <image src="https://img.shields.io/badge/CSS-v3-1572B6.svg?logo=css3&logoColor=1572B6&longCache=true&style=flat">
</a>
<a href="https://nodejs.org/" target="_blank">
    <image src="https://img.shields.io/badge/node--js-vX-339933.svg?logo=node.js&longCache=true&style=flat">
</a>
<br>
<span>Developpé avec : <a href="https://code.visualstudio.com/" target="_blank"><image src="https://img.shields.io/badge/Visual Studio Code-v1.53.2-007ACC.svg?logo=visual-studio-code&logoColor=007ACC&style=flat"></a></span>

## Informations
Sur notre site, vous trouverez :
* Les consignes données
* L'équipe qui travail sur le projet
* Toutes les explications que pourra faire le robot
* Où ça en est pour chaque domaine (réalisation, construction, développement, ...)
* Les devlogs (les avancées du robot)

## Développement
Le site est développé en PhP avec de l'HTML5, des frameworks CC3 (bulma.io et bootstrap) ainsi qu'un peu de JS (JavaScript)

## Réseaux
[Site](https://arduitank.be) - [GitHub](https://github.com/Tank-io)
