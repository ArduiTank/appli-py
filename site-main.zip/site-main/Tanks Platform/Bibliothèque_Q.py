# liste de mots de l'utlisateur
liste_bonjour = ["bjr","bonjour","salut","slt","hello"]

liste_tfq = ["tu fais quoi",'tfq?','tfq ?',"qu'est ce que tu fais?","qu'est ce que tu fais ?","tu fais quoi?","tu fais quoi ?"]

liste_cv = ['comment vas tu','comment vas tu ?','comment vas tu?','comment cv ?','comment ça va ?',
'comment ça va?','comment cv','cv?','cv ?','comment cv?',"comment ça va","comment vas-tu","comment tu vas","ça va"]

liste_quoi = ["tu es quoi?","tu es quoi ?","tu es quoi","qui es tu?","qui es tu ?","qui es tu","qui es-tu"]

liste_danse = ["danses","danse","peux-tu danser","peux tu danser ?","peux tu danser?","peux tu danser"]



 